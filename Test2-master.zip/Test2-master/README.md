This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

* ```npm start``` starts the project on ```localhost:3000```;
* ```npm run test``` runs tests;
* ```npm run storybook``` runs storybook on ```localhost:9009```.
