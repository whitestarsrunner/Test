import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import styled from 'styled-components';

import {add} from '../actions/index';
import {ButtonPrimary, InputPrimary} from '../css-base';

class Creation extends Component {
    state = {
        todoDescription:'',
    }
    
    setTodoDescription = (event) => this.setState({todoDescription: event.target.value});
    
    render() {
        const {add} = this.props;
        return (
        <div>
            <InputPrimary value={this.state.todoDescription} placeholder='Enter Task Description' type='text' onChange={this.setTodoDescription}/>
            <AddButton onClick={()=>{add(this.state.todoDescription); this.setState({todoDescription:''})}}>Add Todo</AddButton>
        </div>
        );
    }
};

const mapDispatchToProps = dispatch => bindActionCreators({
    add,
}, dispatch);

export default connect(null,mapDispatchToProps)(Creation);

export const AddButton = styled(ButtonPrimary)`
    background: #8cffc7;
    &:hover{
        background: #5cf9ad;
    }
`;