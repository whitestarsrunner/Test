import React from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import styled from 'styled-components';

import { remove, toggleStatus, selectedToggler } from '../actions/index';
import {ButtonPrimary, DeleteButton, SelectButton} from '../css-base';

const Todos = props => {
    const {items, filtered, remove, toggleStatus, selectedToggler} = props;
    const todosToRender = (filtered.length === 0) ? items.todos : filtered;
    return todosToRender.map(todo => (
      <Todo selected={todo.selected} key={todo.id}>
        <p>Description: {todo.description}</p>
        <p>Status: {todo.status}</p>
        <DeleteButton onClick={()=>remove(todo.id)}>Remove</DeleteButton>
        <SelectButton onClick={()=>selectedToggler(todo.id)}>Select</SelectButton>
        <ButtonPrimary onClick={()=>toggleStatus(todo.id)}>Toggle Status</ButtonPrimary>
      </Todo>));
}

const mapStateToProps = state => ({
    items: state,
    filtered: state.filtered
});

const mapDispatchToProps = dispatch => bindActionCreators({
    remove,
    toggleStatus,
    selectedToggler,
}, dispatch);

export default connect(mapStateToProps,mapDispatchToProps)(Todos);



const Todo = styled.div`
    margin: 40px;
    padding: 20px;
    width: 30%;
    border-radius: 5px;
    border: 3px solid #9ca2b7;
    background: ${(props)=>props.selected ? '#bbd2f7' : '#white'};
`;