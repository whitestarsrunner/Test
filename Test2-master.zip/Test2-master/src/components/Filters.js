import React from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import styled from 'styled-components';

import {filterByStatus, searchTodo, selectedToggler, removeSelected} from '../actions/index';
import {ButtonPrimary, DeleteButton, SelectButton, InputPrimary} from '../css-base';

const Filters = props => {
    const {filterByStatus, searchTodo, selectedToggler, removeSelected} = props;
    return (
      <div>
        <ButtonPrimary onClick={()=>filterByStatus('Completed')}>Show Completed</ButtonPrimary>
        <ButtonPrimary onClick={()=>filterByStatus('Ongoing')}>Show Ongoing</ButtonPrimary>
        <ButtonPrimary onClick={()=>filterByStatus('Show All')}>Show All</ButtonPrimary>
        <SelectButton onClick={()=>selectedToggler('Select All')}>Select All</SelectButton>
        <DeselectButton onClick={()=>selectedToggler('Deselect All')}>Deselect All</DeselectButton>
        <DeleteButton onClick={()=>removeSelected()}>Remove Selected</DeleteButton>
        <div>
          <InputPrimary placeholder='Enter Search Query' type='text' onChange={event => searchTodo(event.target.value)} />
        </div>
      </div>
    );
};

const mapDispatchToProps = dispatch => bindActionCreators({
    filterByStatus,
    selectedToggler,
    removeSelected,
    searchTodo
}, dispatch);


export default connect(null,mapDispatchToProps)(Filters);

export const DeselectButton = styled(ButtonPrimary)`
    background: #e69bf2;
    &:hover{
        background: #f8ccff;
    }
`;