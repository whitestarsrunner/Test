import reducer from './todoReducer';
describe('todos reducer', () => {
    it('should return the initial state', () => {
      expect(reducer(undefined, {})).toEqual({
        todos: [
            {
                description: 'make it',
                id: 125,
                status: 'Ongoing',
                selected: false,
            }, 
            {
                description: 'made it',
                id: 126,
                status: 'Completed',
                selected: false,
            }, 
        ],
        filtered: []
      })
    })
  })