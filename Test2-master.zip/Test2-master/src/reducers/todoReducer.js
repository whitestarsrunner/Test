const initialState = {
    todos: [
        {
            description: 'make it',
            id: 125,
            status: 'Ongoing',
            selected: false,
        }, 
        {
            description: 'made it',
            id: 126,
            status: 'Completed',
            selected: false,
        }, 
    ],
    filtered: []
};

export default function(state=initialState,action) {
    switch (action.type) {
        case 'ADD':
            let newTodo = {
                description: action.payload,
                id: Date.now(),
                status: 'Ongoing',
                selected: false
            };
            let newState = Object.assign({}, state);
            newState.todos.push(newTodo);
            return newState;
        
        case 'REMOVE':
            state.todos = state.todos.filter(todo => (todo.id !== action.payload));
            return {...state};
            
        case 'TOGGLE_STATUS':
            state.todos.forEach(todo => {
                if (todo.id === action.payload) {
                    (todo.status === 'Ongoing') ? (todo.status = 'Completed') : (todo.status = 'Ongoing')
                }
            })
            return {...state};
        
        case 'FILTER_BY_STATUS':
            if ((action.payload === 'Completed')||((action.payload === 'Ongoing'))) {
                state.filtered = state.todos.filter(todo => (todo.status === action.payload ));
            } else if (action.payload === 'Show All') {
                state.filtered = [];
            }
            return {...state};
        
        case 'SELECTED_TOGGLE':
            if (action.payload === 'Select All') {state.todos.forEach(todo => (todo.selected = true));}
            else if (action.payload === 'Deselect All') {state.todos.forEach(todo => (todo.selected = false));}
            else {
                state.todos.forEach(todo => {
                    if (action.payload === todo.id) todo.selected = !todo.selected;
                })
            }
            return {...state};
        
        case 'REMOVE_SELECTED':
            state.todos = state.todos.filter(todo => !todo.selected);
            return {...state};
        
        case 'SEARCH':
            state.filtered = state.todos.filter(todo => (todo.description.indexOf(action.payload) !== -1));
            return {...state};
            
        default:
            return state;
    }
}