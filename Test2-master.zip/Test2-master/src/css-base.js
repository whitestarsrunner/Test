import styled, {keyframes} from 'styled-components';

const pulse = keyframes`
    {
        0% {
            box-shadow: 0 0 0 0 rgba(70, 0, 150, 0.4);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(70, 0, 150, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(70, 0, 150, 0);
        }
    }
`;

export const ButtonPrimary = styled.button`
    padding: 14px 10px;
    margin: 5px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    outline: 0;
    cursor: pointer;
    &:hover {
        animation: ${pulse} 0.8s infinite;
    }
`;

export const InputPrimary = styled.input`
    margin-left: 5px; 
    border-radius: 4px;
    height: 44px;
    border: 1px solid black;
    position: relative;
    box-sizing: border-box;
    padding-left: 10px;
    outline: 0;
`;

export const DeleteButton = styled(ButtonPrimary)`
    background: #ff8484;
    &:hover{
        background: #f26565;
    }
`;

export const SelectButton = styled(ButtonPrimary)`
    background: #f8ccff;
    &:hover{
        background: #e69bf2;
    }
`;