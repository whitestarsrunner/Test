import React from 'react';
import styled from 'styled-components';

import Creation from './components/Creation';
import Filters from './components/Filters';
import Todos from './components/Todos';

export default () => (
  <AppWrapper>
    <Creation />
    <Filters />
    <Todos />
  </AppWrapper>);

const AppWrapper = styled.div`
  font-family: 'Lato', sans-serif;
  font-size: 18px;
`;