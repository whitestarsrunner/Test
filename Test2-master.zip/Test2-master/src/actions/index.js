export const add = todo => ({
    type: 'ADD',
    payload: todo
});

export const remove = id => ({
    type: 'REMOVE',
    payload: id
});

export const toggleStatus = id => ({
    type: 'TOGGLE_STATUS',
    payload: id
});

export const filterByStatus = status => ({
    type: 'FILTER_BY_STATUS',
    payload: status
});

export const selectedToggler = type => ({
    type: 'SELECTED_TOGGLE',
    payload: type
});

export const removeSelected = () => ({
    type: 'REMOVE_SELECTED'
});

export const searchTodo = query => ({
    type: 'SEARCH',
    payload: query
});