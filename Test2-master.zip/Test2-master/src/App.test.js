import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, configure } from 'enzyme';
import configureStore from 'redux-mock-store';
import Adapter from 'enzyme-adapter-react-16';

import App from './App';
import Creation from './components/Creation';
import Filters from './components/Filters';
import Todos from './components/Todos';

configure({ adapter: new Adapter() });
const mockStore = configureStore();

it('renders without crashing', () => {
  shallow(<App />);
});