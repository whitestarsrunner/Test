import React from 'react';

import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';


import Creation, {AddButton} from '../components/Creation';
import Filters, {DeselectButton}  from '../components/Filters';

import {InputPrimary, ButtonPrimary, DeleteButton, SelectButton} from '../css-base';


storiesOf('Creation', module)
  .add('Add', () => <AddButton onClick={action('add')}>Add</AddButton>)
  .add('Enter Description', () => <InputPrimary placeholder='Enter Description' onChange={action('setTodoDescription')} />);

storiesOf('Filters', module)
  .add('Show Completed', () => <ButtonPrimary onClick={action('filterByStatus')}>Show Completed</ButtonPrimary>)
  .add('Show Ongoing', () => <ButtonPrimary onClick={action('filterByStatus')}>Show Ongoing</ButtonPrimary>)
  .add('Show All', () => <ButtonPrimary onClick={action('filterByStatus')}>Show All</ButtonPrimary>)
  .add('Select All', () => <SelectButton onClick={action('selectedToggler')}>Select All</SelectButton>)
  .add('Deselect All', () => <DeselectButton onClick={action('selectedToggler')}>Deselect All</DeselectButton>)
  .add('Remove Selected', () => <DeleteButton onClick={action('removeSelected')}>Remove Selected</DeleteButton>);